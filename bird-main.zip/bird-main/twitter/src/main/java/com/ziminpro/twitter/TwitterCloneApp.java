package com.ziminpro.twitter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TwitterCloneApp {

	public static void main(String[] args) {
		SpringApplication.run(TwitterCloneApp.class, args);
	}
}
